package com.example.myapplication

import android.view.KeyEvent
import androidx.test.core.app.ActivityScenario.*
import androidx.test.espresso.Espresso.onData
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import org.hamcrest.Matchers.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4ClassRunner::class)
class MainActivityTest {

    private val dummyUser = "dev"
    private val dummyUserNotFound = "asdwdxcw"


    @Before
    fun setup(){
        launch(MainActivity::class.java)
    }

    @Test
    fun searchUser(){
        onView(withId(R.id.userSearchView)).perform(click(),typeText(dummyUserNotFound), closeSoftKeyboard(),pressKey(KeyEvent.KEYCODE_ENTER))
    }

    @Test
    fun userNotFound() {
        onView(withId(R.id.userSearchView)).perform(typeText(dummyUserNotFound), closeSoftKeyboard(),pressKey(KeyEvent.KEYCODE_ENTER))
    }

    @Test
    fun nightMode() {
        onView(withId(R.id.nightmode)).perform(click())
        pressBack()
        launch(MainActivity::class.java)
    }

    @Test
    fun bookmark(){
        onView(withId(R.id.bookmark)).perform(click())
//        onView(withId(R.id.rvItems)).perform(RecyclerViewActions.actionOnItemAtPosition(2, click()));
        onData(allOf(`is`(instanceOf(User::class.java)), `is`(User("ktheofilus","avatar")))) // Use Hamcrest matchers to match item
            .inAdapterView(withId(R.id.recycleView)) // Specify the explicit id of the ListView
            .perform(click()) // Standard ViewAction

    }


}