package com.example.myapplication.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.MainActivity
import com.example.myapplication.User
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito

class MainViewModelTest {

    private lateinit var mainViewModel: MainViewModel
    private lateinit var userViewModel: UserViewModel

    private val dummyUser = User("ktheofilus","https://avatars.githubusercontent.com/u/66745607?v=4")
//    private val dummyUsers:List<User> = dummyUser
    private val dummyUsers=listOf<User>(dummyUser)

    @Rule


    @Before
    fun before() {
//        val activity =Mockito.mock(MainActivity::class.java)
//        Log.d("TAG", "before: $application")
//        Log.d("TAG", "before: $application")
//
//        val factory = ViewModelFactory(activity.application)
//        userViewModel= ViewModelProvider(activity,factory)[UserViewModel::class.java]
//        mainViewModel = ViewModelProvider(activity,factory)[MainViewModel::class.java]
    }

    @Test
    fun findUser(){
//        mainViewModel.findUser("ktheofilus")

//        assertEquals(dummyUsers,mainViewModel.users)

    }


}